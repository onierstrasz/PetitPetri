	
Squeak plug-in running within Leopard

John M McIntosh johnmci at smalltalkconsulting.com 
Thu Nov 8 04:19:44 UTC 2007
Previous message: Squeak plug-in running within Leopard
Next message: FUNSqueak wish a home for download
Messages sorted by: [ date ] [ thread ] [ subject ] [ author ]
It's broken,

First thanks to Steven Riggins of http://www.geeksrus.com/  for  
debugging this over dinner this evening.
At this point we don't know if it's a bug or a feature change in os- 
x. It has to do with how we setup shared memory to share the screen.
It seems we need to pass another option into the shared memory  
creation which was a pre 10.5 a default setting but now it's  
explicit, or a bug.

I've placed a new plugin:   SqueakBrowserPlugin.plugin.3.8.15b15.zip  
on my idisk and ftp site

http://www.smalltalkconsulting.com/squeak.html

After installing the current SqueakLand software, you replace that  
3.8.15b14  SqueakBrowserPlugin.plugin
which is found in /Library/Internet Plug-Ins
or
/Users/foobar/Library/Internet Plug-Ins

by unzipping the zip file and copying the plugin over.


Folks are always encouraged to press the PayPal donate button to help  
pay for this support.


On Nov 6, 2007, at 7:26 PM, Mark Mayfield wrote:

> Greetings...
>
> Is anyone have trouble running the Squeak plug-in within Leopard  
> and Safari
> 3.0.4???
>
> I just get a black region where the Squeak project should be. This is
> happening on both my upgraded laptops.
>
> Thanks,
> Mark Mayfield
>

--
======================================================================== 
===
John M. McIntosh <johnmci at smalltalkconsulting.com>
Corporate Smalltalk Consulting Ltd.  http://www.smalltalkconsulting.com
======================================================================== 
===


Previous message: Squeak plug-in running within Leopard
Next message: FUNSqueak wish a home for download
Messages sorted by: [ date ] [ thread ] [ subject ] [ author ]
More information about the Squeak-dev mailing list

Squeak-dev list courtesy of The InternetOne and tric, the new way