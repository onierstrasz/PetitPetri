
This is an Etoys implementation of a Petri Net interpreter.

Simply download and install Etoys from http://www.squeakland.org/download/

To run the interpreter, simply start EToys and then drag and drop any of the sample files onto the running Etoys image.

Further details can be found here:

http://scg.unibe.ch/Teaching/CP/PetriNets/

Oscar Nierstrasz
2009-01-29
